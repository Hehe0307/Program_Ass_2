#ifndef MAPPING_H_INCLUDED
#define MAPPING_H_INCLUDED

const int row = 12;
const int column = 12;

struct Mapping {
    int xCoord, yCoord;
    int Maze[row][column];
    int *s;
    int stackTop;

    void initializeMaze();
    void Pathing();
    bool isEmptyStack();
    bool isFullStack();
    void push();
    void pop();
    int top();
};

int const MazeSize = 12;

#endif // MAPPING_H_INCLUDED
