#include "mapping.h"
#include "Arduino.h"
#include "constant.h"

void Mapping::initializeMaze(){
  for(int i = 0; i < MazeSize; i++) {
    for(int j = 0; j < MazeSize; j++) {
       Maze[i][j] = 0; // Initialize each element of the Maze to 0
    }
  }
} 

void Mapping::Pathing(){
  
  
}